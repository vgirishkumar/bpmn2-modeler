/**
 */
package org.eclipse.bpmn2.modeler.runtime.jboss.jbpm5.model.drools;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>BP Sim Data Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.bpmn2.modeler.runtime.jboss.jbpm5.model.drools.DroolsPackage#getBPSimDataType()
 * @model
 * @generated
 */
public interface BPSimDataType extends org.eclipse.bpmn2.modeler.runtime.jboss.jbpm5.model.bpsim.BPSimDataType {
} // BPSimDataType
