/**
 */
package org.eclipse.bpmn2.modeler.runtime.jboss.jbpm5.model.bpsim;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Element Parameters Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.bpmn2.modeler.runtime.jboss.jbpm5.model.bpsim.BpsimPackage#getElementParametersType()
 * @model extendedMetaData="name='ElementParametersType' kind='elementOnly'"
 * @generated
 */
public interface ElementParametersType extends ElementParameters {
} // ElementParametersType
