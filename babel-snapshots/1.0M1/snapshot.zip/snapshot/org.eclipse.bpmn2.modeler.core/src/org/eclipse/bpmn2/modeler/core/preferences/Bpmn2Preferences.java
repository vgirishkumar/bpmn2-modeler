/*******************************************************************************
 * Copyright (c) 2011, 2012 Red Hat, Inc.
 *  All rights reserved.
 * This program is made available under the terms of the
 * Eclipse Public License v1.0 which accompanies this distribution,
 * and is available at http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 * Red Hat, Inc. - initial API and implementation
 *
 * @author Bob Brodt
 ******************************************************************************/
package org.eclipse.bpmn2.modeler.core.preferences;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.eclipse.bpmn2.Activity;
import org.eclipse.bpmn2.AdHocSubProcess;
import org.eclipse.bpmn2.BaseElement;
import org.eclipse.bpmn2.CallActivity;
import org.eclipse.bpmn2.CallChoreography;
import org.eclipse.bpmn2.CancelEventDefinition;
import org.eclipse.bpmn2.ChoreographyActivity;
import org.eclipse.bpmn2.Event;
import org.eclipse.bpmn2.EventDefinition;
import org.eclipse.bpmn2.ExclusiveGateway;
import org.eclipse.bpmn2.FlowElementsContainer;
import org.eclipse.bpmn2.Gateway;
import org.eclipse.bpmn2.InteractionNode;
import org.eclipse.bpmn2.ItemAwareElement;
import org.eclipse.bpmn2.Lane;
import org.eclipse.bpmn2.Message;
import org.eclipse.bpmn2.Participant;
import org.eclipse.bpmn2.SubChoreography;
import org.eclipse.bpmn2.SubProcess;
import org.eclipse.bpmn2.Task;
import org.eclipse.bpmn2.TerminateEventDefinition;
import org.eclipse.bpmn2.Transaction;
import org.eclipse.bpmn2.di.BPMNShape;
import org.eclipse.bpmn2.modeler.core.Activator;
import org.eclipse.bpmn2.modeler.core.runtime.TargetRuntime;
import org.eclipse.core.internal.resources.ProjectPreferences;
import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IResource;
import org.eclipse.core.resources.IResourceChangeEvent;
import org.eclipse.core.resources.IResourceChangeListener;
import org.eclipse.core.resources.IWorkspaceRoot;
import org.eclipse.core.resources.ProjectScope;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.Assert;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.preferences.IEclipsePreferences;
import org.eclipse.core.runtime.preferences.IEclipsePreferences.IPreferenceChangeListener;
import org.eclipse.core.runtime.preferences.IEclipsePreferences.PreferenceChangeEvent;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.preference.IPreferenceStore;
import org.eclipse.jface.util.IPropertyChangeListener;
import org.eclipse.jface.util.PropertyChangeEvent;
import org.eclipse.jface.viewers.StructuredSelection;
import org.eclipse.osgi.util.NLS;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.IViewPart;
import org.eclipse.ui.IWorkbench;
import org.eclipse.ui.IWorkbenchPage;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.preferences.ScopedPreferenceStore;
import org.eclipse.ui.views.navigator.ResourceNavigator;
import org.osgi.service.prefs.BackingStoreException;
import org.osgi.service.prefs.Preferences;

@SuppressWarnings("restriction")
public class Bpmn2Preferences implements IPreferenceChangeListener, IPropertyChangeListener, IResourceChangeListener {
	public final static String PROJECT_PREFERENCES_ID = "org.eclipse.bpmn2.modeler"; //$NON-NLS-1$
	public final static String PREF_TARGET_RUNTIME = "target.runtime"; //$NON-NLS-1$
	public final static String PREF_TARGET_RUNTIME_LABEL = Messages.Bpmn2Preferences_Target_Runtime;
	public final static String PREF_SHOW_ADVANCED_PROPERTIES = "show.advanced.properties"; //$NON-NLS-1$
	public final static String PREF_SHOW_ADVANCED_PROPERTIES_LABEL = Messages.Bpmn2Preferences_Show_Advanced_Properties;
	public final static String PREF_SHOW_DESCRIPTIONS = "show.descriptions"; //$NON-NLS-1$
	public final static String PREF_SHOW_DESCRIPTIONS_LABEL = Messages.Bpmn2Preferences_Show_Descriptions;
	public final static String PREF_OVERRIDE_MODEL_ENABLEMENTS = "override.model.enablements"; //$NON-NLS-1$
	public final static String PREF_DEFAULT_MODEL_ENABLEMENT_PROFILE = "default.model.enablement.profile"; //$NON-NLS-1$
	public final static String PREF_IS_HORIZONTAL = "is.horizontal"; //$NON-NLS-1$
	public final static String PREF_IS_HORIZONTAL_LABEL = Messages.Bpmn2Preferences_Horizontal;
	
	public final static String PREF_IS_EXPANDED = "is.expanded"; //$NON-NLS-1$
	public final static String PREF_IS_EXPANDED_LABEL = Messages.Bpmn2Preferences_Expand;
	public final static String PREF_IS_MESSAGE_VISIBLE = "is.message.visible"; //$NON-NLS-1$
	public final static String PREF_IS_MESSAGE_VISIBLE_LABEL = Messages.Bpmn2Preferences_Message_Visible;
	public final static String PREF_IS_MARKER_VISIBLE = "is.marker.visible"; //$NON-NLS-1$
	public final static String PREF_IS_MARKER_VISIBLE_LABEL = Messages.Bpmn2Preferences_Marker_Visible;
	
	public final static String PREF_SHAPE_STYLE = "shape.style"; //$NON-NLS-1$

	public final static String PREF_CONNECTION_TIMEOUT = "connection.timeout"; //$NON-NLS-1$
	public final static String PREF_CONNECTION_TIMEOUT_LABEL = Messages.Bpmn2Preferences_Timeout;

	public final static String PREF_POPUP_CONFIG_DIALOG = "popup.config.dialog"; //$NON-NLS-1$
	public final static String PREF_POPUP_CONFIG_DIALOG_LABEL = Messages.Bpmn2Preferences_Config_Dialog;
	
	public final static String PREF_POPUP_CONFIG_DIALOG_FOR_ACTIVITIES = "popup.config.dialog.for.activities"; //$NON-NLS-1$
	public final static String PREF_POPUP_CONFIG_DIALOG_FOR_ACTIVITIES_LABEL = Messages.Bpmn2Preferences_Activities;
	public final static String PREF_POPUP_CONFIG_DIALOG_FOR_GATEWAYS = "popup.config.dialog.for.gateways"; //$NON-NLS-1$
	public final static String PREF_POPUP_CONFIG_DIALOG_FOR_GATEWAYS_LABEL = Messages.Bpmn2Preferences_Gateways;
	public final static String PREF_POPUP_CONFIG_DIALOG_FOR_EVENTS = "popup.config.dialog.for.events"; //$NON-NLS-1$
	public final static String PREF_POPUP_CONFIG_DIALOG_FOR_EVENTS_LABEL = Messages.Bpmn2Preferences_Events;
	public final static String PREF_POPUP_CONFIG_DIALOG_FOR_EVENT_DEFS = "popup.config.dialog.for.event.defs"; //$NON-NLS-1$
	public final static String PREF_POPUP_CONFIG_DIALOG_FOR_EVENT_DEFS_LABEL = Messages.Bpmn2Preferences_Event_Definitions;
	public final static String PREF_POPUP_CONFIG_DIALOG_FOR_DATA_DEFS = "popup.config.dialog.for.data.defs"; //$NON-NLS-1$
	public final static String PREF_POPUP_CONFIG_DIALOG_FOR_DATA_DEFS_LABEL = Messages.Bpmn2Preferences_Data_Items;
	public final static String PREF_POPUP_CONFIG_DIALOG_FOR_CONTAINERS = "popup.config.dialog.for.containers"; //$NON-NLS-1$
	public final static String PREF_POPUP_CONFIG_DIALOG_FOR_CONTAINERS_LABEL = Messages.Bpmn2Preferences_Containers;

	public final static String PREF_SHOW_ID_ATTRIBUTE = "show.id.attribute"; //$NON-NLS-1$
	public final static String PREF_SHOW_ID_ATTRIBUTE_LABEL = Messages.Bpmn2Preferences_Show_ID_Attribute;
	public final static String PREF_CHECK_PROJECT_NATURE = "check.project.nature"; //$NON-NLS-1$
	public final static String PREF_CHECK_PROJECT_NATURE_LABEL = Messages.Bpmn2Preferences_Check_Project_Nature;
	public final static String PREF_SIMPLIFY_LISTS = "simplify.lists"; //$NON-NLS-1$
	public final static String PREF_SIMPLIFY_LISTS_LABEL = Messages.Bpmn2Preferences_Simplify_Lists;
	public final static String PREF_DO_CORE_VALIDATION = "do.core.validation"; //$NON-NLS-1$
	public final static String PREF_DO_CORE_VALIDATION_LABEL = Messages.Bpmn2Preferences_Do_Core_Validation;

	private static Hashtable<IProject,Bpmn2Preferences> instances = null;
	private static IProject activeProject;

	private IProject project;
	private Preferences projectPreferences;
	private IPreferenceStore globalPreferences;
	private boolean loaded;
	private boolean dirty;
	
	public enum BPMNDIAttributeDefault {
		USE_DI_VALUE,
		DEFAULT_TRUE,
		ALWAYS_TRUE,
		ALWAYS_FALSE
	};
	
	private TargetRuntime targetRuntime;
	private boolean showAdvancedPropertiesTab;
	private boolean overrideModelEnablementProfile;
	private boolean showDescriptions;
	private boolean showIdAttribute;
	private boolean checkProjectNature;
	private boolean simplifyLists;
	private BPMNDIAttributeDefault isHorizontal;
	private BPMNDIAttributeDefault isExpanded;
	private BPMNDIAttributeDefault isMessageVisible;
	private BPMNDIAttributeDefault isMarkerVisible;
	private String connectionTimeout;
	private int popupConfigDialog;
	private boolean popupConfigDialogFor[] = new boolean[6];
	private String defaultModelEnablementProfile = ""; //$NON-NLS-1$
	private boolean doCoreValidation;

	private HashMap<Class, ShapeStyle> shapeStyles = new HashMap<Class, ShapeStyle>();
	
	// TODO: stuff like colors, fonts, etc.

	private Bpmn2Preferences(IProject project) {
		this.project = project;
		IEclipsePreferences rootNode = Platform.getPreferencesService()
				.getRootNode();
		if (project!=null) {
		projectPreferences = rootNode.node(ProjectScope.SCOPE)
				.node(project.getName())
				.node(PROJECT_PREFERENCES_ID);
		if (projectPreferences instanceof ProjectPreferences)
			((ProjectPreferences)projectPreferences).addPreferenceChangeListener(this);
			try {
				projectPreferences.sync();
			}
			catch (Exception e) {
			}
		}		
		globalPreferences = Activator.getDefault().getPreferenceStore();
		globalPreferences.addPropertyChangeListener(this);
		ResourcesPlugin.getWorkspace().addResourceChangeListener(this);
	}

	// various preference instance getters
	
	/**
	 * Return the Preferences for the currently active project. This should be used
	 * with caution: the active project is set by the BPMN2Editor, so this should only
	 * be used in a context that is known to have an active editor.
	 * 
	 * @return project preferences
	 */
	public static Bpmn2Preferences getInstance() {
		return getInstance(getActiveProject());
	}
	
	/**
	 * Return the Preferences for the project containing the EMF Resource
	 * 
	 * @param resource
	 * @return project preferences
	 */
	public static Bpmn2Preferences getInstance(EObject object) {
		return getInstance(object.eResource());
	}
	
	public static Bpmn2Preferences getInstance(Resource resource) {
		return getInstance(resource.getURI());
	}
	
	/**
	 * Return the Preferences for the project containing the EMF Resource specified
	 * by the resource URI. This must be a Platform URI.
	 * 
	 * @param resourceURI
	 * @return project preferences
	 */
	public static Bpmn2Preferences getInstance(URI resourceURI) {
		String filename = resourceURI.trimFragment().toPlatformString(true);
		if (filename==null) {
			return getInstance();
		}
		IWorkspaceRoot root = ResourcesPlugin.getWorkspace().getRoot();
		if (root==null) {
			return getInstance();
		}
		IResource res = ResourcesPlugin.getWorkspace().getRoot().findMember(filename);
		if (res==null) {
			return getInstance();
		}
		IProject project = res.getProject();
		return getInstance(project);
			
	}
	
	/**
	 * Return the Preferences for the given project.
	 * 
	 * @param project
	 * @return project preferences
	 */
	public static Bpmn2Preferences getInstance(IProject project) {
		if (instances==null) {
			instances = new Hashtable<IProject,Bpmn2Preferences>();
		}
		Bpmn2Preferences pref;
		if (project==null)
			pref = new Bpmn2Preferences(null);
		else
			pref = instances.get(project);
		if (pref==null) {
			pref = new Bpmn2Preferences(project);
			instances.put(project, pref);
		}
		return pref;
	}
	
	public IPreferenceStore getGlobalPreferences()
	{
		return globalPreferences;
	}
	
	public Preferences getProjectPreferences()
	{
		return projectPreferences;
	}
	
	public void loadDefaults() {
		String rid = TargetRuntime.getFirstNonDefaultId();
		globalPreferences.setDefault(PREF_TARGET_RUNTIME, rid);
		globalPreferences.setDefault(PREF_SHOW_ADVANCED_PROPERTIES, false);
		globalPreferences.setDefault(PREF_CHECK_PROJECT_NATURE, true);
		globalPreferences.setDefault(PREF_SIMPLIFY_LISTS, true);
		globalPreferences.setDefault(PREF_SHOW_DESCRIPTIONS, true);
		globalPreferences.setDefault(PREF_IS_HORIZONTAL, BPMNDIAttributeDefault.DEFAULT_TRUE.name());
		globalPreferences.setDefault(PREF_IS_EXPANDED, BPMNDIAttributeDefault.ALWAYS_TRUE.name());
		globalPreferences.setDefault(PREF_IS_MESSAGE_VISIBLE, BPMNDIAttributeDefault.ALWAYS_TRUE.name());
		globalPreferences.setDefault(PREF_IS_MARKER_VISIBLE, BPMNDIAttributeDefault.DEFAULT_TRUE.name());

		globalPreferences.setDefault(PREF_POPUP_CONFIG_DIALOG, false); // tri-state checkbox
		globalPreferences.setDefault(PREF_POPUP_CONFIG_DIALOG_FOR_ACTIVITIES, false);
		globalPreferences.setDefault(PREF_POPUP_CONFIG_DIALOG_FOR_GATEWAYS, false);
		globalPreferences.setDefault(PREF_POPUP_CONFIG_DIALOG_FOR_EVENTS, false);
		globalPreferences.setDefault(PREF_POPUP_CONFIG_DIALOG_FOR_EVENT_DEFS, false);
		globalPreferences.setDefault(PREF_POPUP_CONFIG_DIALOG_FOR_DATA_DEFS, false);
		globalPreferences.setDefault(PREF_POPUP_CONFIG_DIALOG_FOR_CONTAINERS, false);
		globalPreferences.setDefault(PREF_DO_CORE_VALIDATION, true);

		for (Class key : shapeStyles.keySet()) {
			globalPreferences.setDefault(getShapeStyleId(key), IPreferenceStore.STRING_DEFAULT_DEFAULT);
		}
		globalPreferences.setDefault(PREF_CONNECTION_TIMEOUT, "1000"); //$NON-NLS-1$
	}
	
	public void restoreDefaults(boolean resetProjectPreferences) {
		loadDefaults();
		if (resetProjectPreferences && projectPreferences != null) {
			projectPreferences.remove(PREF_TARGET_RUNTIME);
			projectPreferences.remove(PREF_SHOW_ADVANCED_PROPERTIES);
			projectPreferences.remove(PREF_SHOW_DESCRIPTIONS);
			projectPreferences.remove(PREF_SHOW_ID_ATTRIBUTE);
			projectPreferences.remove(PREF_CHECK_PROJECT_NATURE);
			projectPreferences.remove(PREF_SIMPLIFY_LISTS);
			projectPreferences.remove(PREF_IS_HORIZONTAL);
			projectPreferences.remove(PREF_IS_EXPANDED);
			projectPreferences.remove(PREF_IS_MESSAGE_VISIBLE);
			projectPreferences.remove(PREF_IS_MARKER_VISIBLE);

			projectPreferences.remove(PREF_POPUP_CONFIG_DIALOG);
			projectPreferences.remove(PREF_POPUP_CONFIG_DIALOG_FOR_ACTIVITIES);
			projectPreferences.remove(PREF_POPUP_CONFIG_DIALOG_FOR_GATEWAYS);
			projectPreferences.remove(PREF_POPUP_CONFIG_DIALOG_FOR_EVENTS);
			projectPreferences.remove(PREF_POPUP_CONFIG_DIALOG_FOR_EVENT_DEFS);
			projectPreferences.remove(PREF_POPUP_CONFIG_DIALOG_FOR_DATA_DEFS);
			projectPreferences.remove(PREF_POPUP_CONFIG_DIALOG_FOR_CONTAINERS);
			projectPreferences.remove(PREF_DO_CORE_VALIDATION);

			for (Class key : shapeStyles.keySet()) {
				projectPreferences.remove(getShapeStyleId(key));
			}
			try {
				projectPreferences.flush();
			} catch (BackingStoreException e) {
				e.printStackTrace();
			}
		}

		globalPreferences.setToDefault(PREF_TARGET_RUNTIME);
		globalPreferences.setToDefault(PREF_SHOW_ADVANCED_PROPERTIES);
		globalPreferences.setToDefault(PREF_SHOW_DESCRIPTIONS);
		globalPreferences.setToDefault(PREF_SHOW_ID_ATTRIBUTE);
		globalPreferences.setToDefault(PREF_CHECK_PROJECT_NATURE);
		globalPreferences.setToDefault(PREF_SIMPLIFY_LISTS);
		globalPreferences.setToDefault(PREF_IS_HORIZONTAL);
		globalPreferences.setToDefault(PREF_IS_EXPANDED);
		globalPreferences.setToDefault(PREF_IS_MESSAGE_VISIBLE);
		globalPreferences.setToDefault(PREF_IS_MARKER_VISIBLE);

		globalPreferences.setToDefault(PREF_POPUP_CONFIG_DIALOG);
		globalPreferences.setToDefault(PREF_POPUP_CONFIG_DIALOG_FOR_ACTIVITIES);
		globalPreferences.setToDefault(PREF_POPUP_CONFIG_DIALOG_FOR_GATEWAYS);
		globalPreferences.setToDefault(PREF_POPUP_CONFIG_DIALOG_FOR_EVENTS);
		globalPreferences.setToDefault(PREF_POPUP_CONFIG_DIALOG_FOR_EVENT_DEFS);
		globalPreferences.setToDefault(PREF_POPUP_CONFIG_DIALOG_FOR_DATA_DEFS);
		globalPreferences.setToDefault(PREF_POPUP_CONFIG_DIALOG_FOR_CONTAINERS);
		globalPreferences.setToDefault(PREF_DO_CORE_VALIDATION);

		List<Class> keys = new ArrayList<Class>();
		keys.addAll(shapeStyles.keySet());
		shapeStyles.clear();
		for (Class key : keys) {
			globalPreferences.setToDefault(getShapeStyleId(key));
			ShapeStyle ss = getShapeStyle(key);
			ss.setDirty(true);
		}
		
		try {
			((ScopedPreferenceStore)globalPreferences).save();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public boolean hasProjectPreference(String key) {
		if (projectPreferences!=null) {
			try {
				String[] keys;
				keys = projectPreferences.keys();
				for (String k : keys) {
					if (k.equals(key))
						return true;
				}
			} catch (Exception e) {
			}
		}
		return false;
	}
	
	public void dispose() {
		if (projectPreferences instanceof ProjectPreferences)
			((ProjectPreferences)projectPreferences).removePreferenceChangeListener(this);
		globalPreferences.removePropertyChangeListener(this);
		if (project!=null)
			instances.remove(project);
		ResourcesPlugin.getWorkspace().removeResourceChangeListener(this);
	}
	
	public synchronized void reload() {
		loaded = false;
		load();
		dirty = false;
	}
	
	public void load() {
		
		if (!loaded) {
			// load all preferences
			loadDefaults();
			
			if (projectPreferences!=null) {
				overrideModelEnablementProfile = projectPreferences.getBoolean(PREF_OVERRIDE_MODEL_ENABLEMENTS, false);
				defaultModelEnablementProfile = projectPreferences.get(PREF_DEFAULT_MODEL_ENABLEMENT_PROFILE, ""); //$NON-NLS-1$
			}

			String id = getString(PREF_TARGET_RUNTIME,TargetRuntime.getFirstNonDefaultId());
			if (id==null || id.isEmpty())
				id = TargetRuntime.getFirstNonDefaultId();
			targetRuntime = TargetRuntime.getRuntime(id);
			showAdvancedPropertiesTab = getBoolean(PREF_SHOW_ADVANCED_PROPERTIES, false);
			showDescriptions = getBoolean(PREF_SHOW_DESCRIPTIONS, false);
			showIdAttribute = getBoolean(PREF_SHOW_ID_ATTRIBUTE, false);
			checkProjectNature = getBoolean(PREF_CHECK_PROJECT_NATURE, false);
			simplifyLists = getBoolean(PREF_SIMPLIFY_LISTS, true);
			isHorizontal = getBPMNDIAttributeDefault(PREF_IS_HORIZONTAL, BPMNDIAttributeDefault.USE_DI_VALUE);
			isExpanded = getBPMNDIAttributeDefault(PREF_IS_EXPANDED, BPMNDIAttributeDefault.USE_DI_VALUE);
			isMessageVisible = getBPMNDIAttributeDefault(PREF_IS_MESSAGE_VISIBLE, BPMNDIAttributeDefault.USE_DI_VALUE);
			isMarkerVisible = getBPMNDIAttributeDefault(PREF_IS_MARKER_VISIBLE, BPMNDIAttributeDefault.USE_DI_VALUE);
			connectionTimeout = this.getString(PREF_CONNECTION_TIMEOUT, "60000"); //$NON-NLS-1$
			
			popupConfigDialog = getInt(PREF_POPUP_CONFIG_DIALOG, 0); // tri-state checkbox
			popupConfigDialogFor[0] = getBoolean(PREF_POPUP_CONFIG_DIALOG_FOR_ACTIVITIES, false);
			popupConfigDialogFor[1] = getBoolean(PREF_POPUP_CONFIG_DIALOG_FOR_GATEWAYS, false);
			popupConfigDialogFor[2] = getBoolean(PREF_POPUP_CONFIG_DIALOG_FOR_EVENTS, false);
			popupConfigDialogFor[3] = getBoolean(PREF_POPUP_CONFIG_DIALOG_FOR_EVENT_DEFS, false);
			popupConfigDialogFor[4] = getBoolean(PREF_POPUP_CONFIG_DIALOG_FOR_DATA_DEFS, false);
			popupConfigDialogFor[5] = getBoolean(PREF_POPUP_CONFIG_DIALOG_FOR_CONTAINERS, false);

			doCoreValidation = getBoolean(PREF_DO_CORE_VALIDATION, true);

			loaded = true;
		}
	}
	
	public synchronized void save() throws BackingStoreException {
		if (dirty) {
			// this is the only preference that is a project property,
			// and not saved in the preference store for this plugin.
			if (projectPreferences!=null) {
				projectPreferences.putBoolean(PREF_OVERRIDE_MODEL_ENABLEMENTS, overrideModelEnablementProfile);
				projectPreferences.put(PREF_DEFAULT_MODEL_ENABLEMENT_PROFILE, defaultModelEnablementProfile);
			}

			setString(PREF_TARGET_RUNTIME,getRuntime().getId());
			setBoolean(PREF_SHOW_ADVANCED_PROPERTIES, showAdvancedPropertiesTab);
			setBoolean(PREF_SHOW_DESCRIPTIONS, showDescriptions);
			setBoolean(PREF_SHOW_ID_ATTRIBUTE, showIdAttribute);
			setBoolean(PREF_CHECK_PROJECT_NATURE, checkProjectNature);
			setBoolean(PREF_SIMPLIFY_LISTS, simplifyLists);
			setBPMNDIAttributeDefault(PREF_IS_HORIZONTAL, isHorizontal);

			setBPMNDIAttributeDefault(PREF_IS_EXPANDED, isExpanded);
			setBPMNDIAttributeDefault(PREF_IS_MESSAGE_VISIBLE, isMessageVisible);
			setBPMNDIAttributeDefault(PREF_IS_MARKER_VISIBLE, isMarkerVisible);
			
			setString(PREF_CONNECTION_TIMEOUT, connectionTimeout);

			setInt(PREF_POPUP_CONFIG_DIALOG, popupConfigDialog);
			setBoolean(PREF_POPUP_CONFIG_DIALOG_FOR_ACTIVITIES, popupConfigDialogFor[0]);
			setBoolean(PREF_POPUP_CONFIG_DIALOG_FOR_GATEWAYS, popupConfigDialogFor[1]);
			setBoolean(PREF_POPUP_CONFIG_DIALOG_FOR_EVENTS, popupConfigDialogFor[2]);
			setBoolean(PREF_POPUP_CONFIG_DIALOG_FOR_EVENT_DEFS, popupConfigDialogFor[3]);
			setBoolean(PREF_POPUP_CONFIG_DIALOG_FOR_DATA_DEFS, popupConfigDialogFor[4]);
			setBoolean(PREF_POPUP_CONFIG_DIALOG_FOR_CONTAINERS, popupConfigDialogFor[5]);
			setBoolean(PREF_DO_CORE_VALIDATION, doCoreValidation);
		}
		
		for (Entry<Class, ShapeStyle> entry : shapeStyles.entrySet()) {
			setShapeStyle(entry.getKey(), entry.getValue());
		}
		
		if (projectPreferences!=null) {
			projectPreferences.flush();
		}

		dirty = false;
	}
	
	public static String getShapeStyleId(EObject object) {
		try {
			Class clazz = Class.forName(object.eClass().getInstanceClassName());
			return getShapeStyleId(clazz);
		} catch (ClassNotFoundException e) {
			return getShapeStyleId(object.getClass());
		}
	}
	
	public static String getShapeStyleId(Class clazz) {
		return clazz.getSimpleName() + "." + PREF_SHAPE_STYLE; //$NON-NLS-1$
	}

	public ShapeStyle getShapeStyle(EObject object) {
		Class clazz;
		try {
			clazz = Class.forName(object.eClass().getInstanceClassName());
			return getShapeStyle(clazz);
		} catch (ClassNotFoundException e) {
			return getShapeStyle(object.getClass());
		}
	}
	
	public ShapeStyle getShapeStyle(Class clazz) {
		ShapeStyle ss = shapeStyles.get(clazz);
		if (ss==null) {
			// maybe the given class is a subclass of one that we know about?
			for (Entry<Class, ShapeStyle> entry : shapeStyles.entrySet()) {
				Class c = entry.getKey();
				if (c.isAssignableFrom(clazz)) {
					ss = entry.getValue();
					break;
				}
			}
		}
		if (ss==null) {
			String key = getShapeStyleId(clazz);
			String value;
			if (hasProjectPreference(key)) {
				value = projectPreferences.get(key, ""); //$NON-NLS-1$
			}
			else {
				value = globalPreferences.getString(key);
				if (value.isEmpty()) {
					//get from TargetRuntime
					ss = getRuntime().getShapeStyle(clazz);
					if (ss==null) {
						if (!TargetRuntime.DEFAULT_RUNTIME_ID.equals(getRuntime().getId())) {
							// search default runtime
							ss = TargetRuntime.getDefaultRuntime().getShapeStyle(clazz);
						}
						if (ss==null) {
							// give up
							ss = new ShapeStyle();
						}
					}
					// don't cache this because we don't want to save it PreferenceStore
					return ss;
				}
			}
			ss = ShapeStyle.decode(value);
			shapeStyles.put(clazz, ss);
		}
		return ss;
	}
	
	public void setShapeStyle(Class clazz, ShapeStyle style) {
		if (style.isDirty()) {
			String key = getShapeStyleId(clazz);
			String value = ShapeStyle.encode(style);
			if (hasProjectPreference(key))
				projectPreferences.put(key, value);
			else
				globalPreferences.setValue(key, value);
			shapeStyles.put(clazz, style);
			style.setDirty(false);
			dirty = true;
		}
	}
	
	public TargetRuntime getRuntime() {
		load();
		if (targetRuntime==null) {
			targetRuntime = TargetRuntime.getDefaultRuntime();
			Display.getDefault().asyncExec( new Runnable() {
				@Override
				public void run() {
					String id = getString(PREF_TARGET_RUNTIME,TargetRuntime.getFirstNonDefaultId());
					if (id==null || id.isEmpty())
						id = TargetRuntime.getFirstNonDefaultId();

					targetRuntime = TargetRuntime.getDefaultRuntime();
					MessageDialog.openError(
						Display.getDefault().getActiveShell(),
						Messages.Bpmn2Preferences_No_Runtime_Plugin_Title,
						NLS.bind(
							Messages.Bpmn2Preferences_No_Runtime_Plugin_Message,
							id,
							targetRuntime.getDescription()
						)
					);
				}
				
			});
					
		}
		return targetRuntime;
	}

	public void setRuntime(TargetRuntime rt) {
		
		Assert.isTrue(rt!=null);
		overrideGlobalString(PREF_TARGET_RUNTIME, rt.getId());
		targetRuntime = rt;
	}
	
	public boolean getShowAdvancedPropertiesTab() {
		load();
		return showAdvancedPropertiesTab;
	}
	
	public void setShowAdvancedPropertiesTab(boolean show) {
		overrideGlobalBoolean(PREF_SHOW_ADVANCED_PROPERTIES, show);
		showAdvancedPropertiesTab = show;
	}
	
	public boolean getShowDescriptions() {
		load();
		return showDescriptions;
	}
	
	public void setShowDescriptions(boolean show) {
		overrideGlobalBoolean(PREF_SHOW_DESCRIPTIONS, show);
		showDescriptions = show;
	}
	
	public boolean getShowIdAttribute() {
		load();
		return showIdAttribute;
	}
	
	public void setShowIdAttribute(boolean show) {
		overrideGlobalBoolean(PREF_SHOW_ID_ATTRIBUTE, show);
		showIdAttribute = show;
	}
	
	public boolean getCheckProjectNature() {
		load();
		return checkProjectNature;
	}
	
	public void setCheckProjectNature(boolean show) {
		overrideGlobalBoolean(PREF_CHECK_PROJECT_NATURE, show);
		checkProjectNature = show;
	}
	
	public boolean getSimplifyLists() {
		load();
		return simplifyLists;
	}
	
	public void setSimplifyLists(boolean simplify) {
		overrideGlobalBoolean(PREF_SIMPLIFY_LISTS,simplify);
		simplifyLists = simplify;
	}

	public boolean getOverrideModelEnablementProfile() {
		load();
		return overrideModelEnablementProfile;
	}
	
	public void setOverrideModelEnablements(boolean override) {
		overrideModelEnablementProfile = override;
		dirty = true;
	}

	public String getDefaultModelEnablementProfile() {
		load();
		return defaultModelEnablementProfile;
	}
	
	public void setDefaultModelEnablementProfile(String profile) {
		defaultModelEnablementProfile = profile;
		dirty = true;
	}
	
	public boolean getShowPopupConfigDialog(Object context) {
		load();
		if (popupConfigDialog!=0) {
			if (context instanceof Task || context instanceof ChoreographyActivity) {
				return popupConfigDialogFor[0];
			}
			if (context instanceof Gateway) {
				return popupConfigDialogFor[1];
			}
			if (context instanceof Event) {
				return popupConfigDialogFor[2];
			}
			if (context instanceof EventDefinition) {
				if (context instanceof CancelEventDefinition || context instanceof TerminateEventDefinition)
					return false; // these have no additional attributes
				return popupConfigDialogFor[3];
			}
			if (context instanceof ItemAwareElement || context instanceof Message) {
				return popupConfigDialogFor[4];
			}
			if (context instanceof InteractionNode || context instanceof FlowElementsContainer) {
				return popupConfigDialogFor[5];
			}
		}
		return false;
	}
	
	public boolean hasPopupConfigDialog(Object context) {
		if (context instanceof Activity) {
			return true;
		}
		if (context instanceof Gateway) {
			return true;
		}
		if (context instanceof Event) {
			return true;
		}
		if (context instanceof EventDefinition) {
			if (context instanceof CancelEventDefinition || context instanceof TerminateEventDefinition)
				return false; // these have no additional attributes
			return true;
		}
		if (context instanceof ItemAwareElement || context instanceof Message) {
			return true;
		}
		if (context instanceof InteractionNode
				|| context instanceof FlowElementsContainer
				|| context instanceof CallChoreography) {
			return true;
		}
		return false;
	}
	
	public void setShowPopupConfigDialog(Object context, boolean value) {
		overrideGlobalInt(PREF_POPUP_CONFIG_DIALOG,  value ? 1 : 0);
		popupConfigDialog = value ? 1 : 0;
	}
	
	public boolean getDoCoreValidation() {
		load();
		return doCoreValidation;
	}
	
	public void setDoCoreValidation(boolean enable) {
		overrideGlobalBoolean(PREF_DO_CORE_VALIDATION, enable);
		doCoreValidation = enable;
	}

	public boolean isHorizontalDefault() {
		load();
		return isHorizontal==BPMNDIAttributeDefault.ALWAYS_TRUE ||
				isHorizontal==BPMNDIAttributeDefault.DEFAULT_TRUE;
	}

	public BPMNDIAttributeDefault getIsHorizontal() {
		return isHorizontal;
	}
	
	public void setIsHorizontal(BPMNDIAttributeDefault value) {
		overrideGlobalBPMNDIAttributeDefault(PREF_IS_HORIZONTAL, value);
		this.isHorizontal = value;
	}

	public boolean isExpandedDefault() {
		load();
		return isExpanded==BPMNDIAttributeDefault.ALWAYS_TRUE ||
				isExpanded==BPMNDIAttributeDefault.DEFAULT_TRUE;
	}

	public BPMNDIAttributeDefault getIsExpanded() {
		load();
		return isExpanded;
	}

	public void setIsExpanded(BPMNDIAttributeDefault value) {
		overrideGlobalBPMNDIAttributeDefault(PREF_IS_EXPANDED, value);
		this.isExpanded = value;
	}

	public BPMNDIAttributeDefault getIsMessageVisible() {
		load();
		return isMessageVisible;
	}

	public void setIsMessageVisible(BPMNDIAttributeDefault value) {
		overrideGlobalBPMNDIAttributeDefault(PREF_IS_MESSAGE_VISIBLE, value);
		this.isMessageVisible = value;
	}

	public BPMNDIAttributeDefault getIsMarkerVisible() {
		load();
		return isMarkerVisible;
	}

	public void setIsMarkerVisible(BPMNDIAttributeDefault value) {
		overrideGlobalBPMNDIAttributeDefault(PREF_IS_MARKER_VISIBLE, value);
		this.isMarkerVisible = value;
	}

	public String getConnectionTimeout() {
		load();
		return connectionTimeout;
	}
	
	public void setConnectionTimeout(String value) {
		try {
			Integer.parseInt(value);
			overrideGlobalString(PREF_CONNECTION_TIMEOUT, value);
			this.connectionTimeout = value;
		}
		catch (Exception e) {
		}
	}
	
	// this is temporary until the connection routing has been proven reliable
	static boolean enableConnectionRouting = true;
	public boolean getEnableConnectionRouting() {
		return enableConnectionRouting;
	}
	
	public void setEnableConnectionRouting(boolean enable) {
		this.enableConnectionRouting = enable;
	}
	
	@Override
	public void preferenceChange(PreferenceChangeEvent event) {
		reload();
	}

	/* (non-Javadoc)
	 * @see org.eclipse.jface.util.IPropertyChangeListener#propertyChange(org.eclipse.jface.util.PropertyChangeEvent)
	 */
	@Override
	public void propertyChange(PropertyChangeEvent event) {
		reload();
	}

	// preference/property getters and setters
	public boolean getBoolean(String key, boolean defaultValue) {
		if (hasProjectPreference(key))
			return projectPreferences.getBoolean(key, defaultValue);
		if (globalPreferences.contains(key))
			return globalPreferences.getBoolean(key);
		return defaultValue;
	}
	
	public void setBoolean(String key, boolean value) {
		if (hasProjectPreference(key))
			projectPreferences.putBoolean(key, value);
		else
			globalPreferences.setValue(key, value);
	}

	private void overrideGlobalBoolean(String key, boolean value) {
		projectPreferences.putBoolean(key, value);
		saveProjectPreferences();
		dirty = true;
	}
	
	public int getInt(String key, int defaultValue) {
		if (hasProjectPreference(key))
			return projectPreferences.getInt(key, defaultValue);
		if (globalPreferences.contains(key))
			return globalPreferences.getInt(key);
		return defaultValue;
	}
	
	public void setInt(String key, int value) {
		if (hasProjectPreference(key))
			projectPreferences.putInt(key, value);
		else
			globalPreferences.setValue(key, value);
	}

	private void overrideGlobalInt(String key, int value) {
		projectPreferences.putInt(key, value);
		saveProjectPreferences();
		dirty = true;
	}
	
	public String getString(String key, String defaultValue) {
		if (hasProjectPreference(key))
			return projectPreferences.get(key, defaultValue);
		if (globalPreferences.contains(key))
			return globalPreferences.getString(key);
		return defaultValue;
	}
	
	public void setString(String key, String value) {
		if (hasProjectPreference(key))
			projectPreferences.put(key, value);
		else
			globalPreferences.setValue(key, value);
	}

	private void overrideGlobalString(String key, String value) {
		projectPreferences.put(key, value);
		saveProjectPreferences();
		dirty = true;
	}

	public BPMNDIAttributeDefault getBPMNDIAttributeDefault(String key, BPMNDIAttributeDefault defaultValue) {
		BPMNDIAttributeDefault value = null;
		if (hasProjectPreference(key))
			value = BPMNDIAttributeDefault.valueOf(projectPreferences.get(key, defaultValue.name()));
		else if (globalPreferences.contains(key))
			value = BPMNDIAttributeDefault.valueOf(globalPreferences.getString(key));
		else
			value = defaultValue;
		return value;
	}
	
	public void setBPMNDIAttributeDefault(String key, BPMNDIAttributeDefault value) {
		if (hasProjectPreference(key))
			projectPreferences.put(key, value.name());
		else
			globalPreferences.setValue(key, value.name());
	}

	private void overrideGlobalBPMNDIAttributeDefault(String key, BPMNDIAttributeDefault value) {
		projectPreferences.put(key, value.name());
		saveProjectPreferences();
		dirty = true;
	}

	public static String[] getBPMNDIAttributeDefaultChoices() {
		BPMNDIAttributeDefault[] values = BPMNDIAttributeDefault.values();
		String[] choices = new String[values.length];
		int i = 0;
		for (BPMNDIAttributeDefault v : values) {
			String text = Messages.Bpmn2Preferences_None;
			switch (v) {
			case USE_DI_VALUE:
				text = Messages.Bpmn2Preferences_False_if_not_set;
				break;
			case DEFAULT_TRUE:
				text = Messages.Bpmn2Preferences_True_if_not_set;
				break;
			case ALWAYS_TRUE:
				text = Messages.Bpmn2Preferences_Always_true;
				break;
			case ALWAYS_FALSE:
				text = Messages.Bpmn2Preferences_Always_False;
				break;
			}
			choices[i++] = text;
		}
		return choices;
	}
	
	public static String[][] getBPMNDIAttributeDefaultChoicesAndValues() {
		String[] choices = getBPMNDIAttributeDefaultChoices();
		BPMNDIAttributeDefault[] values = BPMNDIAttributeDefault.values();
		String[][] choicesAndValues = new String[choices.length][2];
		int i = 0;
		for (BPMNDIAttributeDefault v : values) {
			choicesAndValues[i][0] = choices[i];
			choicesAndValues[i][1] = v.name();
			++i;
		}
		return choicesAndValues;
	}
	
	/**
	 * Applies preference defaults to a BPMNShape object. The <code>attribs</code> map should contain
	 * only those attributes that are set on the BPMNShape object (as read from the bpmn XML file).
	 * This is used to determine the appropriate default values for certain optional attributes, e.g.
	 * isHorizontal, isExpanded, etc.
	 * 
	 * @param bpmnShape - the BPMNShape object whose attributes are to be set
	 * @param attribs - map of BPMN DI attributes currently set on the BPMNShape object. May be null.
	 * @see getIsHorizontal(), getIsExpanded(), getIsMessageVisible() and getIsMarkerVisible()
	 */
	public void applyBPMNDIDefaults(BPMNShape bpmnShape, Map<String,String>attribs) {
		boolean isHorizontalSet = false;
		boolean isExpandedSet = false;
		boolean isMessageVisibleSet = false;
		boolean isMarkerVisibleSet = false;
		boolean choreographyActivityShapeSet = false;
		
		if (attribs != null) {
			for (Entry<String, String> entry : attribs.entrySet()) {
				String name = entry.getKey();
				if ("isHorizontal".equals(name)) { //$NON-NLS-1$
					isHorizontalSet = true;
				}
				if ("isExpanded".equals(name)) { //$NON-NLS-1$
					isExpandedSet = true;
				}
				if ("isMessageVisible".equals(name)) { //$NON-NLS-1$
					isMessageVisibleSet = true;
				}
				if ("isMarkerVisible".equals(name)) { //$NON-NLS-1$
					isMarkerVisibleSet = true;
				}
				if ("choreographyActivityShape".equals(name)) { //$NON-NLS-1$
					choreographyActivityShapeSet = true;
				}
			}
		}
		
		BaseElement be = bpmnShape.getBpmnElement();
		
		// isHorizontal only applies to Pools and Lanes, not Participant bands
		if (!isHorizontalSet) {
			if ((be instanceof Participant && !choreographyActivityShapeSet) || be instanceof Lane) {
				boolean horz = isHorizontalDefault();
				bpmnShape.setIsHorizontal(horz);
			}
		}
		else {
			if ((be instanceof Participant && !choreographyActivityShapeSet) || be instanceof Lane) {
				BPMNDIAttributeDefault df = getIsHorizontal();
				switch(df) {
				case ALWAYS_TRUE:
					bpmnShape.setIsHorizontal(true);
					break;
				case ALWAYS_FALSE:
					bpmnShape.setIsHorizontal(false);
					break;
				}

			}
		}
		
		// isExpanded only applies to activity containers (SubProcess, AdHocSubProcess, etc.)
		if (!isExpandedSet) {
			if (be instanceof  SubProcess ||
					be instanceof AdHocSubProcess ||
					be instanceof Transaction ||
					be instanceof SubChoreography ||
					be instanceof CallActivity ||
					be instanceof CallChoreography) {
				boolean value = false;
				BPMNDIAttributeDefault df = getIsExpanded();
				switch(df) {
				case ALWAYS_TRUE:
				case DEFAULT_TRUE:
					value = true;
					break;
				case ALWAYS_FALSE:
				case USE_DI_VALUE:
					value = false;
				}
				bpmnShape.setIsExpanded(value);
			}
		}
		else {
			if (be instanceof  SubProcess ||
					be instanceof AdHocSubProcess ||
					be instanceof Transaction ||
					be instanceof SubChoreography ||
					be instanceof CallActivity ||
					be instanceof CallChoreography) {
				BPMNDIAttributeDefault df = getIsExpanded();
				switch(df) {
				case ALWAYS_TRUE:
					bpmnShape.setIsExpanded(true);
					break;
				case ALWAYS_FALSE:
					bpmnShape.setIsExpanded(false);
					break;
				}
			}
		}
		
		// isMessageVisible only applies to Participant Bands
		if (!isMessageVisibleSet) {
			if (be instanceof Participant && choreographyActivityShapeSet) {
				boolean value = false;
				BPMNDIAttributeDefault df = getIsMessageVisible();
				switch(df) {
				case ALWAYS_TRUE:
				case DEFAULT_TRUE:
					value = true;
					break;
				case ALWAYS_FALSE:
				case USE_DI_VALUE:
					value = false;
				}
				bpmnShape.setIsMessageVisible(value);
			}
		}
		else {
			if (be instanceof Participant && choreographyActivityShapeSet) {
				BPMNDIAttributeDefault df = getIsMessageVisible();
				switch(df) {
				case ALWAYS_TRUE:
					bpmnShape.setIsMessageVisible(true);
					break;
				case ALWAYS_FALSE:
					bpmnShape.setIsMessageVisible(false);
					break;
				}
			}
		}
		
		// isMarkerVisible only applies to ExclusiveGateway
		if (!isMarkerVisibleSet) {
			if (be instanceof ExclusiveGateway) {
				BPMNDIAttributeDefault df = getIsMarkerVisible();
				switch(df) {
				case ALWAYS_TRUE:
				case DEFAULT_TRUE:
					bpmnShape.setIsMarkerVisible(true);
					break;
				case ALWAYS_FALSE:
				case USE_DI_VALUE:
					bpmnShape.setIsMarkerVisible(false);
					break;
				}
			}
		}
		else {
			if (be instanceof ExclusiveGateway) {
				BPMNDIAttributeDefault df = getIsMarkerVisible();
				switch(df) {
				case ALWAYS_TRUE:
					bpmnShape.setIsMarkerVisible(true);
					break;
				case ALWAYS_FALSE:
					bpmnShape.setIsMarkerVisible(false);
					break;
				}
			}
		}
	}

	// TODO: use CNF for indigo & future - keep ResourceNavigator for backward compatibility
	public static IProject getActiveProject() {
		if (activeProject!=null)
			return activeProject;
		
		IWorkbench workbench = PlatformUI.getWorkbench(); 
		IWorkbenchWindow window = workbench.getActiveWorkbenchWindow();
		if (window!=null) {
			IWorkbenchPage page = window.getActivePage();
			if (page!=null) {
				IViewPart[] parts = page.getViews();
		
				for (int i = 0; i < parts.length; i++) {
					if (parts[i] instanceof ResourceNavigator) {
						ResourceNavigator navigator = (ResourceNavigator) parts[i];
						StructuredSelection sel = (StructuredSelection) navigator.getTreeViewer().getSelection();
						IResource resource = (IResource) sel.getFirstElement();
						if (resource!=null) {
							activeProject = resource.getProject();
							break;
						}
					}
				}
			}
		}
		return activeProject;
	}

	public static void setActiveProject(IProject project) {
		activeProject = project;
	}

	/* (non-Javadoc)
	 * @see org.eclipse.core.resources.IResourceChangeListener#resourceChanged(org.eclipse.core.resources.IResourceChangeEvent)
	 */
	@Override
	public void resourceChanged(IResourceChangeEvent event) {
		int type = event.getType();
		if (type==IResourceChangeEvent.PRE_CLOSE) {
			try {
				save();
			} catch (Exception e) {
				e.printStackTrace();
			}
			dispose();
		}
		if (type==IResourceChangeEvent.PRE_DELETE)
			dispose();
	}

	private void saveProjectPreferences() {
		try {
			projectPreferences.flush();
		} catch (BackingStoreException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
