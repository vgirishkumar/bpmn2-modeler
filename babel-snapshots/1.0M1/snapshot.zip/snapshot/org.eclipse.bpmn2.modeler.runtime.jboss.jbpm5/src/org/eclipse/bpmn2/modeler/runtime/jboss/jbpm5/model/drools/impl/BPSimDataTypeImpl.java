/**
 */
package org.eclipse.bpmn2.modeler.runtime.jboss.jbpm5.model.drools.impl;

import org.eclipse.bpmn2.modeler.runtime.jboss.jbpm5.model.drools.BPSimDataType;
import org.eclipse.bpmn2.modeler.runtime.jboss.jbpm5.model.drools.DroolsPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>BP Sim Data Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class BPSimDataTypeImpl extends org.eclipse.bpmn2.modeler.runtime.jboss.jbpm5.model.bpsim.impl.BPSimDataTypeImpl implements BPSimDataType {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BPSimDataTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DroolsPackage.Literals.BP_SIM_DATA_TYPE;
	}

} //BPSimDataTypeImpl
