/**
 */
package org.eclipse.bpmn2.modeler.runtime.jboss.jbpm5.model.drools;

import org.eclipse.bpmn2.CallableElement;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Callable Element Proxy</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.bpmn2.modeler.runtime.jboss.jbpm5.model.drools.DroolsPackage#getExternalProcess()
 * @model
 * @generated
 */
public interface ExternalProcess extends CallableElement {
} // ExternalProcess
